from MST_plus_plus.test_develop_code.utils import *
from MST_plus_plus.test_develop_code.architecture import *
def my_summary(test_model, H = 256, W = 256, C = 31, N = 1):
    model = test_model.cuda()
    print(model)
    inputs = torch.randn((N, C, H, W)).cuda()
    flops = FlopCountAnalysis(model,inputs)
    n_param = sum([p.nelement() for p in model.parameters()])
    print(f'GMac:{flops.total()/(1024*1024*1024)}')
    print(f'Params:{n_param}')

my_summary(MST_Plus_Plus(),640,640,3,1)