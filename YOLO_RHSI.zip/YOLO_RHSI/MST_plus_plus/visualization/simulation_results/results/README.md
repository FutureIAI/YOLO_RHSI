Please put the reconstructed HSI here and rename it as method.mat, e.g., mst_s.mat. 
