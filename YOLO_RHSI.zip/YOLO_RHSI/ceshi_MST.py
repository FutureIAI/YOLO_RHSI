import torch
from MST_plus_plus.predict_code.architecture import *
pretrained_model_path = "MST_plus_plus/predict_code/model_zoo/hinet.pth"
pre_model = HINet(depth=4)
checkpoint = torch.load(pretrained_model_path)
pre_model.load_state_dict({k.replace('module.', ''): v for k, v in checkpoint['state_dict'].items()},
                                   strict=False)
print("sfsfsfsf")