from ultralytics import YOLO
from ultralytics.utils import ASSETS
from ultralytics.models.yolo.detect import DetectionPredictor
if __name__ == '__main__':


    model = YOLO("train/weights/best.pt")
    sources = "111.jpg"
    results = model(sources, visualize=True, iou=0.5, save=True)