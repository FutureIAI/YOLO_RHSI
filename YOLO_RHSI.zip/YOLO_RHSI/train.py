import torch
import torch.nn as nn
from MST_plus_plus.predict_code.architecture import *
from ultralytics import YOLO


yoloModel = YOLO("ultralytics/cfg/models/v8/yolov8s_RHSI.yaml")
print(yoloModel)
print("test")
results = yoloModel.train(data="data.yml", epochs=500, imgsz=640,batch=12)
